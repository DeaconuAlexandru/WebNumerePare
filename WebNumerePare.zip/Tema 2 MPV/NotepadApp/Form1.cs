using System;
using System.Windows.Forms;
using System.IO;

namespace NotepadApp
{
    public partial class Form1 : Form
    {
        private TextBox textBox;
        private MenuStrip menuStrip;
        private ToolStripMenuItem fileMenu;
        private ToolStripMenuItem openMenuItem;
        private ToolStripMenuItem saveMenuItem;
        private ToolStripMenuItem launchAppMenuItem;

        public Form1()
        {
            InitializeComponent();

            this.Text = "Notepad";
            this.Width = 800;
            this.Height = 600;

            textBox = new TextBox();
            textBox.Multiline = true;
            textBox.Dock = DockStyle.Fill;
            textBox.ScrollBars = ScrollBars.Both;
            this.Controls.Add(textBox);

            menuStrip = new MenuStrip();
            fileMenu = new ToolStripMenuItem("File");
            openMenuItem = new ToolStripMenuItem("Open");
            saveMenuItem = new ToolStripMenuItem("Save");
            launchAppMenuItem = new ToolStripMenuItem("Open NumerePareApp");

            openMenuItem.Click += OpenMenuItem_Click;
            saveMenuItem.Click += SaveMenuItem_Click;
            launchAppMenuItem.Click += LaunchAppMenuItem_Click;

            fileMenu.DropDownItems.Add(openMenuItem);
            fileMenu.DropDownItems.Add(saveMenuItem);
            fileMenu.DropDownItems.Add(new ToolStripSeparator()); // separator vizual
            fileMenu.DropDownItems.Add(launchAppMenuItem);
            menuStrip.Items.Add(fileMenu);
            this.Controls.Add(menuStrip);
            this.MainMenuStrip = menuStrip;
        }

        private void OpenMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                textBox.Text = File.ReadAllText(openFileDialog.FileName);
            }
        }

        private void SaveMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(saveFileDialog.FileName, textBox.Text);
            }
        }

        private void LaunchAppMenuItem_Click(object sender, EventArgs e)
        {
            string path = @"C:\Users\deaco\OneDrive\Desktop\Tema 2 MPV\NumerePareApp\bin\Debug\net9.0-windows\NumerePareApp.exe";

            if (File.Exists(path))
            {
                System.Diagnostics.Process.Start(path);
            }
            else
            {
                MessageBox.Show("Aplicația NumerePareApp nu a fost găsită!", "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
