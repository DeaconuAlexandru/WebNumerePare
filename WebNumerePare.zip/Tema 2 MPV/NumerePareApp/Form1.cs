using System;
using System.Windows.Forms;
using System.Drawing;

namespace NumerePareApp
{
    public partial class Form1 : Form
    {
        private Label titleLabel;
        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button button1;
        int i = 0, n;

        public Form1()
        {
            InitializeComponent();

            // Setări generale fereastră
            this.Text = "Numere Pare";
            this.BackColor = Color.LightGreen;
            this.ClientSize = new Size(500, 300);
            this.Font = new Font("Microsoft Sans Serif", 9);

            // Titlu centrat sus
            titleLabel = new Label();
            titleLabel.Text = "Afișarea numerelor pare mai mici ca o valoare dată";
            titleLabel.TextAlign = ContentAlignment.MiddleCenter;
            titleLabel.BackColor = Color.Yellow;
            titleLabel.ForeColor = Color.Black;
            titleLabel.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);
            titleLabel.Size = new Size(460, 30);
            titleLabel.Location = new Point(20, 10);
            this.Controls.Add(titleLabel);

            int offsetY = 50; // mută totul în jos cu 2 rânduri

            // Label 1
            label1 = new Label();
            label1.Text = "Introduceți valoarea:";
            label1.Location = new Point(30, 30 + offsetY);
            label1.ForeColor = Color.Black;
            label1.BackColor = Color.Yellow;
            label1.AutoSize = true;
            this.Controls.Add(label1);

            // TextBox 1
            textBox1 = new TextBox();
            textBox1.Location = new Point(200, 30 + offsetY);
            textBox1.BackColor = Color.Yellow;
            textBox1.ForeColor = Color.Black;
            this.Controls.Add(textBox1);

            // Buton START
            button1 = new Button();
            button1.Text = "START";
            button1.Location = new Point(200, 65 + offsetY);
            button1.BackColor = Color.Yellow;
            button1.ForeColor = Color.Black;
            button1.Click += new EventHandler(Button1_Click);
            this.Controls.Add(button1);

            // TextBox 2 (afișare rezultate)
            textBox2 = new TextBox();
            textBox2.Location = new Point(200, 105 + offsetY);
            textBox2.Width = 200;
            textBox2.Height = 100;
            textBox2.Multiline = true;
            textBox2.ScrollBars = ScrollBars.Vertical;
            textBox2.BackColor = Color.Yellow;
            textBox2.ForeColor = Color.Black;
            this.Controls.Add(textBox2);
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out n))
            {
                textBox2.Text = "";
                for (i = 0; i < n; i += 2)
                {
                    textBox2.Text += i.ToString() + Environment.NewLine;
                }
            }
            else
            {
                MessageBox.Show("Introduceți un număr valid!", "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}